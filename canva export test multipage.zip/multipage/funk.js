(function(){
const W=1920,H=1080,stage=document.getElementById('stage'),deck=document.getElementById('deck');
if(!stage)return;
function resize(){const s=Math.min(stage.clientWidth/W,stage.clientHeight/H);deck.style.transform='scale('+s+')'}
new ResizeObserver(resize).observe(stage);resize();
const links=document.querySelectorAll('.pagenav a');
addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key===' ')links[2].click();else if(e.key==='ArrowLeft')links[0].click();else if(e.key==='Escape')location.href='index.html'});
})();